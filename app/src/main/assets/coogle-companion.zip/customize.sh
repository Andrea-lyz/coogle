#!/system/bin/sh
PACKAGE=com.google.android.googlequicksearchbox
APP_DIR=$MODPATH/system/priv-app/GoogleQuickSearchBox

mkdir -p "$APP_DIR"
find "$APP_DIR" -maxdepth 1 -type f -name '*.apk' -delete 2>/dev/null

pm path "$PACKAGE" 2>/dev/null |
  sed -n 's/^package://p' |
  while IFS= read -r apk; do
    [ -f "$apk" ] || continue
    cp -f "$apk" "$APP_DIR/${apk##*/}"
done

set_perm_recursive $MODPATH 0 0 0755 0644

set_perm_recursive "$MODPATH/system" 0 0 0755 0644
for script in boot-completed.sh setup.sh uninstall.sh prepare-audio.sh status.sh features.sh post-fs-data.sh; do
    set_perm "$MODPATH/$script" 0 0 0755
done
/system/bin/sh "$MODPATH/prepare-audio.sh"
. "$MODPATH/features.sh"
load_features /dev/null
if grep -q '^controlVersion=1$' /data/adb/modules/coogle_companion/module.prop 2>/dev/null; then
    load_features /data/adb/modules/coogle_companion/features.conf
fi
save_features "$MODPATH/features.conf" || abort "Cannot save component choices"
MODDIR=$MODPATH
apply_features || abort "Cannot prepare selected components"
ui_print "Google system app, enrollment and DSP support combined. Reboot required."
ui_print "Hey Google follows the Coogle switch; live translation enables automatically after reboot."
