#!/system/bin/sh
PACKAGE=com.google.android.googlequicksearchbox
APP_DIR=$MODPATH/system/priv-app/GoogleQuickSearchBox

mkdir -p "$APP_DIR"
find "$APP_DIR" -maxdepth 1 -type f -name '*.apk' -delete 2>/dev/null

pm path "$PACKAGE" 2>/dev/null |
  sed -n 's/^package://p' |
  while IFS= read -r apk; do
    [ -f "$apk" ] || continue
    cp -f "$apk" "$APP_DIR/${apk##*/}"
done

set_perm_recursive $MODPATH 0 0 0755 0644

set_perm_recursive "$MODPATH/system" 0 0 0755 0644
for script in boot-completed.sh setup.sh uninstall.sh prepare-audio.sh status.sh features.sh post-fs-data.sh action.sh; do
    set_perm "$MODPATH/$script" 0 0 0755
done
/system/bin/sh "$MODPATH/prepare-audio.sh"
. "$MODPATH/features.sh"
load_features /data/adb/modules/coogle_companion/features.conf
save_features "$MODPATH/features.conf" || abort "Cannot save component choices"
if [ "$COOGLE_NONINTERACTIVE" != 1 ]; then
    ui_print "请选择支持组件：音量＋开启，音量－关闭；最后保存或取消。"
    /system/bin/sh "$MODPATH/action.sh" || ui_print "未保存新选择，保留原配置继续安装。"
fi
load_features "$MODPATH/features.conf"
MODDIR=$MODPATH
apply_features || abort "Cannot prepare selected components"
ui_print "Google system app, enrollment and DSP support combined. Reboot required."
ui_print "Action: choose Google system app, Hey Google and live translation support."
